
const C=(window.ATLAS_CONFIG||{}).firebase;
if(C&&C.apiKey){
try{
const B='https://www.gstatic.com/firebasejs/11.0.2/';
const {initializeApp}=await import(B+'firebase-app.js');
const A=await import(B+'firebase-auth.js');
const app=initializeApp(C),auth=A.getAuth(app);auth.languageCode='pt-BR';
await A.setPersistence(auth,A.browserLocalPersistence);
const googleProvider=new A.GoogleAuthProvider();googleProvider.setCustomParameters({prompt:'select_account'});
window.FB={
google:()=>window.Capacitor?.isNativePlatform?.()?A.signInWithRedirect(auth,googleProvider):A.signInWithPopup(auth,googleProvider),
email:(email,password)=>A.signInWithEmailAndPassword(auth,email,password),
signup:(email,password)=>A.createUserWithEmailAndPassword(auth,email,password),
profile:(name)=>auth.currentUser?A.updateProfile(auth.currentUser,{displayName:name}):Promise.resolve(),
reset:(email)=>A.sendPasswordResetEmail(auth,email),out:()=>A.signOut(auth),del:()=>A.deleteUser(auth.currentUser),
user:()=>auth.currentUser,async token(){await auth.authStateReady();return auth.currentUser?auth.currentUser.getIdToken():''}};
A.onAuthStateChanged(auth,u=>{S.authReady=true;S.authInitializing=false;if(u)finishAuth(u);else{S.in=0;S.authBusy=false;S.v='login';save();draw()}});
try{const rr=await A.getRedirectResult(auth);if(rr?.user)finishAuth(rr.user)}catch(e){S.authReady=true;S.authInitializing=false;S.authBusy=false;S.authError=authErrorMessage(e,'login');draw()}
window.dispatchEvent(new Event('fbready'));
}catch(e){S.authReady=true;S.authInitializing=false;S.authError='Não foi possível inicializar o Firebase Authentication.';window.dispatchEvent(new Event('fbready'));draw()}
}else{S.authInitializing=false;S.authReady=true;draw()}
