# ATLAS — Dola-style productivity update

This build keeps the existing ATLAS visual designer and adds a Dola-inspired productivity layer.

## Added
- Natural-language local calendar events: create, list, edit and delete.
- Agenda screen with the existing ATLAS cards, buttons, sheets and typography.
- Calendar export as `.ics` for Google Calendar, Apple Calendar and CalDAV workflows.
- Google Calendar OAuth scope and event push support through Firebase Google sign-in.
- Reminder/task flow remains available and is surfaced as a dedicated ATLAS card.
- Event-time notifications through the existing notification system.
- Weather screen using Open-Meteo with device geolocation and daily forecast subscription state.
- Web search shortcut from the home composer using the existing ATLAS sheet UI.
- Messenger integration configuration UI for WhatsApp, Telegram, LINE and Apple Messages.
- All new state is persisted with the existing `atlas.v2` storage architecture.

## Existing ATLAS features preserved
- Firebase authentication
- Dify / ATLAS backend configuration
- Rápido / Pro model selector
- Voice call and hold-to-speak UI
- Camera, Photos, Files and attachment tray
- Web page reader
- Image creation with references
- Drive/files UI
- Conversation history and actions
- ATLAS visual design system

## Important backend notes
- WhatsApp, Telegram, LINE and Apple Messages require actual bot/webhook infrastructure to operate end-to-end. The UI now has a configuration surface for those channels.
- Google Calendar event push requires the user to authorize Calendar access with Google.
- Apple Calendar/CalDAV uses `.ics` export in this client build; full bidirectional CalDAV requires a secure backend.
- Weather uses Open-Meteo and browser/device geolocation.
