# ATLAS Image API

- Provider: Google Gemini Interactions API
- Model: `gemini-3.1-flash-image` (Nano Banana 2)
- Endpoint: `https://generativelanguage.googleapis.com/v1beta/interactions`
- Authentication: `x-goog-api-key`
- Reference images: supported as base64 image inputs.

## Test status
A live request could not be completed in the build environment because outbound DNS/network access was unavailable. The app is wired to the documented REST endpoint and includes HTTP error handling.

## Security
The user-provided API key is embedded in `assets/public/config.js` at the user's explicit request. This exposes the key to anyone who can inspect the APK/web assets. For production, move it to the ATLAS backend and revoke/rotate this key if the APK is distributed publicly.
