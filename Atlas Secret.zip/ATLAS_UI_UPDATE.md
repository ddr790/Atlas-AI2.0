# ATLAS UI / interaction update

Applied to the extracted Capacitor web bundle:

- Chat composer attachment tray modeled on the supplied reference: Camera, Photos, Files, Call.
- Plus button becomes an X while the attachment tray is open.
- Utility pages (Drive and Scheduled Tasks) now show "Voltar à ATLAS" only there and return to the previously open chat.
- Added a custom in-app camera screen with preview, shutter and camera switch controls.
- Added a real URL input for "Ler página da Web". The app retrieves readable page content through the reader endpoint and attaches the page text to the conversation.
- Added a voice hold interaction: enter voice mode, then press-and-hold "Segure para falar" to capture speech, with recording animation.
- Added recent-image thumbnails to the attachment tray when images have been selected.
- Kept Firebase authentication and the existing Dify configuration intact.

This package contains modified extracted app resources. It is not a rebuilt/signed APK.
