// Firebase Web configuration for the ATLAS app.
// These values are Firebase's public web-app configuration and are safe to ship
// to the browser. Authentication security is enforced by Firebase rules/providers.
window.ATLAS_CONFIG={firebase:{apiKey:"AIzaSyBvPeD3bK456OOVD5mdUnmGZNkp0wBUOzU",authDomain:"atlas-9f28f.firebaseapp.com",projectId:"atlas-9f28f",storageBucket:"atlas-9f28f.firebasestorage.app",messagingSenderId:"69441691797",appId:"1:69441691797:web:ddc0dba7dbdfb977b7fb9c",measurementId:"G-20P74J8S77"}};

// Image generation configuration (user-provided key).
window.ATLAS_IMAGE_CONFIG={apiKey:"AQ.Ab8RN6LbNVc-qwt-MuuOTVnTyc93CN_njeZz6PJbn9nmpBQkiA",model:"gemini-3.1-flash-image"};
